package com.nirav.demorest;

import java.util.Arrays;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("students")
public class StudentResource {
	
	StudentRepository sr = new StudentRepository();
	
	@GET
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_XML})	
	public List<Student> getAllStudent()
	{	
		
		return sr.getAllStudent();
		
	}
	
	@GET
	@Path("student/{roll}")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_XML})
	public Student getStudent(@PathParam("roll") int roll)
	{
		return sr.getStudent(roll);
	}
	
	
	@POST
    @Path("add")
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_XML})
	public Student createStudent(Student s1)
	{
		System.out.println(s1);
		sr.addStudent(s1);
		return s1;
	}
	
	@PUT
	@Path("update")
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_XML})
	public Student upStudent(Student s1)
	{
		System.out.println(s1);
		if(sr.getStudent(s1.getRoll())==null)
		{
			sr.addStudent(s1);
		}
		else
		{
			sr.updateStudent(s1);
		}
			return s1;
	}
	
	@DELETE
	@Path("delete/{roll}")
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_XML})
	public Student removeStudent(@PathParam("roll") int roll)
	{	
		Student s1 = sr.getStudent(roll);
		if(s1 != null)
		{
		sr.deleteStudent(roll);
		}
		return s1;
	}
	
}
