package com.nirav.demorest;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class StudentRepository {
	List<Student> studentList;
	Connection con = null;
	public Statement st;
	public ResultSet rs;
	public PreparedStatement pst;
	
	public Connection connect()
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/demorest","root","root");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		return con;
	}
	
	
	public List<Student> getAllStudent()
	{
		studentList = new ArrayList<Student>();	
		try {
			con = this.connect();
			st = con.createStatement();
			rs = st.executeQuery("select * from student");
			while(rs.next())
			{
				Student s = new Student();
				s.setRoll(rs.getInt("roll"));
				s.setName(rs.getString("name"));
				studentList.add(s);
			}
			con.close();
			}catch (Exception e) {
				e.printStackTrace();
			}
		return studentList;
		
	}
	
	public void addStudent(Student s)
	{
		
		try {
			con = this.connect();
			pst = con.prepareStatement("insert into student(roll,name) values(?,?)");
			pst.setInt(1, s.getRoll());
			pst.setString(2, s.getName());
			pst.executeUpdate();
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	public Student getStudent(int roll) {
		Student s = null;
		try {
			
			con = this.connect();
			pst = con.prepareStatement("select * from student where roll = ?");
			pst.setInt(1, roll);
			rs = pst.executeQuery();
			while(rs.next())
			{
				s = new Student();
				s.setRoll(rs.getInt("roll"));
				s.setName(rs.getString("name"));
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}
	
	
	public void updateStudent(Student s)
	{
		try {
			con = this.connect();
			pst = con.prepareStatement("update student set name = ? where roll = ?");
			pst.setString(1, s.getName());
			pst.setInt(2, s.getRoll());
			pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}


	public void deleteStudent(int roll) {
		try {
			con = this.connect();
			pst = con.prepareStatement("delete from student where roll = ?");
			pst.setInt(1, roll);
			pst.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
			
		}
		
	}
}
